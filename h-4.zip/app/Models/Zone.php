<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Zone extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
    ];

    public function service()
    {
        return $this->hasMany(ServiceZone::class);
    }

    public function services_zones()
    {
        return $this->hasMany(ServiceZone::class);
    }	
}